#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
APPDIR="$HOME/.local/share/applications"
mkdir -p "$APPDIR"
# Desktop Entry paths escape spaces and backslashes per desktop-entry conventions.
escape_path() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/ /\\ /g'; }
EXEC_PATH=$(escape_path "$HERE/oyunu-baslat.sh")
ICON_PATH=$(escape_path "$HERE/icon.svg")
cat > "$APPDIR/kucuk-kasif.desktop" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=Küçük Kaşif
Comment=Pardus için derlemesiz macera oyunu
Exec=$EXEC_PATH
Icon=$ICON_PATH
Terminal=false
Categories=Game;ArcadeGame;
StartupNotify=true
DESKTOP
chmod +x "$APPDIR/kucuk-kasif.desktop"
if command -v update-desktop-database >/dev/null 2>&1; then update-desktop-database "$APPDIR" >/dev/null 2>&1 || true; fi
printf '%s\n' 'Küçük Kaşif uygulama menüsüne eklendi.'
printf '%s\n' 'Uygulamalar menüsünden Küçük Kaşif diye aratıp başlatabilirsin.'
printf '%s\n' 'Bazı masaüstü ortamlarında .desktop dosyasına sağ tıklayıp Başlatmaya izin ver seçmek gerekebilir.'
