KÜÇÜK KAŞİF — PARDUS PRO
========================

Tek dosyalı HTML5 Canvas macera oyunu. Derleme, kurulum veya internet bağlantısı gerektirmez.

BAŞLATMA
1. ZIP paketini bir klasöre çıkar.
2. index.html dosyasını Firefox/Chromium ile aç.
3. İstersen terminalden ./oyunu-baslat.sh komutunu çalıştır.

PARDUS UYGULAMA MENÜSÜ
Terminalde oyun klasöründe:
  ./masaustu-kisayolu-kur.sh
Sonra Pardus uygulamalar menüsünde "Küçük Kaşif" diye ara.

KONTROLLER
- Sol/Sağ ok veya A/D: hareket
- Shift: koş
- Yukarı ok/W/Boşluk: zıpla
- ESC veya P: duraklat
- R: yeniden başlat
- Dokunmatik kontroller ekranda görünür.

YENİ ÖZELLİKLER
- İlk açılışta oyuncu adı; sonraki açılışlarda kişisel karşılama
- Yerel profil, altın cüzdanı, rekor, başarımlar ve hatıra defteri
- Otomatik ilerleme kaydı ve "Kaldığın Yerden Devam Et"
- Kostüm mağazası, takip eden evcil hayvan ve üç görsel dünya teması
- Tarihe göre yenilenen günlük görevler ve ödüller
- E tuşuyla girilen gizli mağara ve tek seferlik altın hazinesi
- Üç can puanlı vadi patronu; yenmeden bitiş bayrağı açılmaz
- JSON kayıt yedeği dışa aktarma ve içe alma
- Çevrimdışı çalışma; oyun verileri tarayıcının yerel depolamasında tutulur.

KAYIT HAKKINDA
Kayıtlar yalnızca aynı kullanıcı hesabındaki aynı tarayıcı profiline kaydedilir. Tarayıcı verileri temizlenirse yerel kayıt silinebilir; menüdeki "Kaydı Yedekle" seçeneğini kullan. JSON yedek başka cihaza taşınabilir.

NOT
Bu sürüm gerçek Pardus cihazında test edilmedi. Modern Firefox veya Chromium tabanlı bir tarayıcı gerektirir.
