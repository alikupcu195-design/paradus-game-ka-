#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
FILE="$HERE/index.html"
if command -v xdg-open >/dev/null 2>&1; then
  exec xdg-open "$FILE"
elif command -v firefox >/dev/null 2>&1; then
  exec firefox "$FILE"
elif command -v chromium >/dev/null 2>&1; then
  exec chromium "$FILE"
elif command -v chromium-browser >/dev/null 2>&1; then
  exec chromium-browser "$FILE"
else
  printf '%s\n' 'Bir tarayıcı bulunamadı. Pardus Yazılım Merkezi üzerinden Firefox kurup index.html dosyasını aç.'
  exit 1
fi
